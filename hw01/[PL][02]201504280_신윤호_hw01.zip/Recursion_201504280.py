def sum(n):
    if n < 1 :
        return 0
    else :
        return n+sum(n-1)

def fibonacci(n):
    if n == 0 :
        return 0
    elif n == 1 :
        return 1
    else :
        return (fibonacci(n-1)+fibonacci(n-2))

def factorial(n):
    if n<=1 :
        return 1
    else :
        return n*factorial(n-1)

def decimal_to_binary(n):
    if n<2 :
        return n
    else :
        return (10*decimal_to_binary(n/2))+n%2


def TestRecursionFunction() :
    print(sum(100))
    print(fibonacci(10))
    print(factorial(10))
    print(decimal_to_binary(15))

TestRecursionFunction()
